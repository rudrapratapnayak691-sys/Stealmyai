# Friday
Nural system ai
